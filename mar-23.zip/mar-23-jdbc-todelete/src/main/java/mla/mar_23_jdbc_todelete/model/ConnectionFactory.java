package mla.mar_23_jdbc_todelete.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	private String driver, url, username, password;
	public ConnectionFactory() {
		System.out.println("No arg constructor");
	}
	
	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		System.out.println("setting the driver now...");
		this.driver = driver;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public ConnectionFactory(String driver, String url, String username, String password) {
		super();
		System.out.println("Constructor with parameters");
		this.driver = driver;
		this.url = url;
		this.username = username;
		this.password = password;
	}

	public Connection getConnection() throws ClassNotFoundException, SQLException
	{
		Class.forName(driver);
		return DriverManager.getConnection(url, username, password);
	}
}
