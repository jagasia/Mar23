package mla.mar_23_jdbc_todelete;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import mla.mar_23_jdbc_todelete.model.ConnectionFactory;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws ClassNotFoundException, SQLException
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        ConnectionFactory cf= (ConnectionFactory) ctx.getBean("con");
        
//        ConnectionFactory cf=new ConnectionFactory();
//        cf.setDriver("oracle.jdbc.driver.OracleDriver");
//        cf.setUrl("jdbc:oracle:thin:@localhost:1522:xe");
//        cf.setUsername("sys as sysdba");
//        cf.setPassword("password");
        Connection con = cf.getConnection();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM Employees");
        while(rs.next())
        	System.out.println(rs.getString(2));
    }
}
