package mla.mar_23_aop_1;

public class Logging {
	//transaction
	public void after()
	{
		System.out.println("After tasks going on...");
	}
	public void before()
	{
		System.out.println("Before tasks going on...");
	}
	public void around()
	{
		System.out.println("Around: Now the withdrawal is going on...");
	}
}
