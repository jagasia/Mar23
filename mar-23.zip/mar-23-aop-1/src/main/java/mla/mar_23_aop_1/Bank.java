package mla.mar_23_aop_1;

public class Bank {
	public void withdraw()
	{
		System.out.println("Withdrawing money now...");
	}
	
	public void depost() {}
}
