package mla.mar_23_aop_1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        Bank bank=(Bank) ctx.getBean("bank");
        bank.withdraw();
    }
}
