package mla.mar_23_aop_annotations;

import org.springframework.stereotype.Component;

@Component
public class Bank {
	public void withdraw()
	{
		System.out.println("Withdrawing...");
	}
	public void deposit()
	{
		System.out.println("Depositing...");
	}
}
