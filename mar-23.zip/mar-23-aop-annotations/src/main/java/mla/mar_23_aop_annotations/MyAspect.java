package mla.mar_23_aop_annotations;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Aspect
@EnableAspectJAutoProxy
@Component
public class MyAspect {
	@Pointcut("execution(* mla.mar_23_aop_annotations.*.*(..))")
	public void selectAll()
	{
		
	}
	
	@Before("selectAll()")
	public void validatePin()
	{
		System.out.println("Before: validating the pin");
	}
	
	@After("selectAll()")
	public void dispenseCash()
	{
		System.out.println("After: remember to collect the cash");
	}
}
