package mla.mar_23_aop_annotations;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
        ctx.scan("mla.mar_23_aop_annotations");
        ctx.refresh();
        Bank bank=(Bank) ctx.getBean("bank");
        bank.withdraw();
        System.out.println();
        bank.deposit();
    }
}
