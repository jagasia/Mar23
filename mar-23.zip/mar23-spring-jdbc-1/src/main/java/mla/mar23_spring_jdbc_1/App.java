package mla.mar23_spring_jdbc_1;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import mla.mar23_spring_jdbc_1.model.Branch;
import mla.mar23_spring_jdbc_1.model.BranchRowMapper;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
//        DriverManagerDataSource dmds=new DriverManagerDataSource();
//        dmds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
//        dmds.setUrl("jdbc:oracle:thin:@localhost:1522:xe");
//        dmds.setUsername("sys as sysdba");
//        dmds.setPassword("password");
//        
//        JdbcTemplate jt=new JdbcTemplate();
//        jt.setDataSource(dmds);
//        
//        jt.execute("CREATE TABLE DUMMY101 (SNO INT)");
//        System.out.println("Checkk db");
        
        
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        JdbcTemplate jt=(JdbcTemplate) ctx.getBean("jt");
        //jt.execute("CREATE TABLE DUMMY103(SNO INT)");
//        jt.update("INSERT INTO Branch VALUES (?,?,?)","B00016","Vasantha nagar","Madurai");
        	
//        Branch branch = jt.queryForObject("SELECT * FROM Branch WHERE bid=?", new BranchRowMapper(),"B00014");
//        System.out.println(branch);
        
        
        RowMapper<Branch> rm=new RowMapper<Branch>() {
			
			public Branch mapRow(ResultSet rs, int rowNum) throws SQLException {
				Branch branch=new Branch();
				branch.setBid(rs.getString(1));
				branch.setBname(rs.getString(2));
				branch.setBcity(rs.getString(3));
				return branch;
			}
		};
        
        
        List<Branch> result = jt.query("select * from Branch where bcity=?", rm,"Delhi");
        
        for(Branch b : result)
        	System.out.println(b);

        System.out.println("Check...");
    }
}
