package mla.mar_23_autowire.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Car {
	private String name;
	@Autowired
	@Qualifier("abc")
	private Audio audio;
	
	public Car() {}

	public Car(String name, Audio audio) {
		super();
		this.name = name;
		this.audio = audio;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Audio getAudio() {
		return audio;
	}

	public void setAudio(Audio audio) {
		this.audio = audio;
	}

	@Override
	public String toString() {
		return "Car [name=" + name + ", audio=" + audio + "]";
	}
	
	
}
