package mla.mar_23_autowire.model;


public interface Audio {
	void play();
}
