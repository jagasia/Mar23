package mla.mar_23_autowire.model;


public class Sony implements Audio {

	public void play() {
		System.out.println("Sony plays music");

	}

}
