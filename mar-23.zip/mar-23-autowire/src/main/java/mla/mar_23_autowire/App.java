package mla.mar_23_autowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import mla.mar_23_autowire.model.Car;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        Car car= (Car) ctx.getBean("car");
        System.out.println(car);
//        car.getAudio().play();
    }
}
