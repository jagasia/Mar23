package mla.mar_23_ioc.model;

public interface Audio {
	void play();
}
