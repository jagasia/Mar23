package mla.mar_23_ioc.model;

public class Sony implements Audio {

	public void play() {
		System.out.println("Sony plays music");

	}

}
