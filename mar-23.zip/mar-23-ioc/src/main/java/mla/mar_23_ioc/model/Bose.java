package mla.mar_23_ioc.model;

public class Bose implements Audio {

	public void play() {
		System.out.println("Bose audio plays sound");

	}

}
