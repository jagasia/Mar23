package mla.mar_23_ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import mla.mar_23_ioc.model.Audio;
import mla.mar_23_ioc.model.Car;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        Car car=(Car) ctx.getBean("car");
        System.out.println(car);
//        car.getAudio().play();
        
        Audio audio=(Audio) ctx.getBean("sony");
        car.setAudio(audio);			//setter based injection	
        System.out.println(car);
        car.getAudio().play();
    }
}
