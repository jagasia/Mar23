package mla.mar_23_bean_1.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Bus {
	@Autowired
	Sony sony;
	public Bus() {}
	public Bus(Sony sony) {
		super();
		this.sony = sony;
	}
	public Sony getSony() {
		return sony;
	}
	public void setSony(Sony sony) {
		this.sony = sony;
	}
	@Override
	public String toString() {
		return "Bus [sony=" + sony + "]";
	}
	
}
