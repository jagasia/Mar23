package mla.mar_23_bean_1.model;

import org.springframework.stereotype.Component;

@Component("bose")
public class Bose implements Audio {

	public void play() {
		System.out.println("Bose audio plays sound");

	}

}
