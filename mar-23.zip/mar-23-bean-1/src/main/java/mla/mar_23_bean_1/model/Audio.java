package mla.mar_23_bean_1.model;


public interface Audio {
	void play();
}
