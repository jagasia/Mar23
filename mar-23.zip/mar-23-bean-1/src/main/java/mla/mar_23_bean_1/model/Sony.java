package mla.mar_23_bean_1.model;

import org.springframework.stereotype.Component;

@Component("sony")
public class Sony implements Audio {

	public void play() {
		System.out.println("Sony plays music");

	}

}
