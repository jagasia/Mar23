package mla.mar_23_bean_1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import mla.mar_23_bean_1.model.Audio;
import mla.mar_23_bean_1.model.Bose;
import mla.mar_23_bean_1.model.Car;
import mla.mar_23_bean_1.model.Sony;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
        ctx.scan("mla.mar_23_bean_1.model");
        ctx.refresh();
        Car car=ctx.getBean(Car.class);
        car.setName("Maruti");
        System.out.println(car);
        car.getAudio().play();
        
        Audio audio=ctx.getBean(Sony.class);
        car.setAudio(audio);
        car.getAudio().play();
    }
}
