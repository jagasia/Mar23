package mla.mar_23_spring_2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import mla.mar_23_spring_2.model.Customer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        Customer x = (Customer) ctx.getBean("cust");
        System.out.println(x);
    }
}
